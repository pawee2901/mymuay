import { NextResponse } from 'next/server';
import { prisma } from '@/db';
import imaps from 'imap-simple';
import { simpleParser } from 'mailparser';

export const dynamic = 'force-dynamic';

const MAILY_API_URL = "https://api.maily.space/mail/public/mails";
const MAILY_TOKEN = process.env.MAILY_TOKEN || "sk_v1_jtv42y05jqab3e1is2xh85nfwuhnp5x1";
const CLOUD_RUN_URL = "https://getemails-wfudlrftlq-uc.a.run.app/getEmails";

function getAppCode(name) {
  const lower = name.toLowerCase();
  if (lower.includes('netflix')) return 'NF';
  if (lower.includes('disney')) return 'DN';
  if (lower.includes('true')) return 'TM';
  if (lower.includes('chat') || lower.includes('openai') || lower.includes('gpt')) return 'GPT';
  if (lower.includes('prime') || lower.includes('amazon')) return 'PR';
  return 'GPT';
}

function matchesApp(from, subject, name) {
  const lowerFrom = (from || '').toLowerCase();
  const lowerSub = (subject || '').toLowerCase();
  const lowerApp = (name || '').toLowerCase();
  
  if (lowerApp.includes('netflix')) {
    return lowerFrom.includes('netflix') || lowerSub.includes('netflix');
  } else if (lowerApp.includes('disney')) {
    return lowerFrom.includes('disney') || lowerSub.includes('disney');
  } else if (lowerApp.includes('true')) {
    return lowerFrom.includes('true') || lowerSub.includes('true');
  } else if (lowerApp.includes('chat') || lowerApp.includes('openai')) {
    return lowerFrom.includes('openai') || lowerSub.includes('openai') || lowerFrom.includes('chatgpt') || lowerSub.includes('chatgpt');
  } else if (lowerApp.includes('prime') || lowerApp.includes('amazon')) {
    return lowerFrom.includes('prime') || lowerSub.includes('prime') || lowerFrom.includes('amazon') || lowerSub.includes('amazon');
  }
  return false;
}

function extractOtpCode(htmlBody) {
  if (!htmlBody) return null;
  const plainText = htmlBody.replace(/<[^>]*>?/gm, ' ');
  
  let match = plainText.match(/\b\d{6}\b/);
  if (match) return match[0];
  
  match = plainText.match(/\b\d{4,8}\b/);
  if (match) return match[0];
  
  return null;
}

export async function POST(request) {
  try {
    const { appId, email } = await request.json();

    if (!appId || !email || !email.includes('@')) {
      return NextResponse.json({ error: 'ข้อมูลไม่ครบถ้วน' }, { status: 400 });
    }

    const lowerEmail = email.toLowerCase().trim();
    const originalEmail = email.trim();

    let matchingMails = [];

    const mailyDomains = ["@lico.moe", "@rdcw.plus", "@gooddaymail.com"];
    const isMailyDomain = mailyDomains.some(d => lowerEmail.includes(d));

    if (isMailyDomain) {
      // ---------------------------------------------------------
      // Channel A: Maily Space API
      // ---------------------------------------------------------
      const parts = lowerEmail.split('@');
      const accountName = parts[0].trim();
      const domainId = parts[1].trim().replace(/\./g, '');

      const queryParams = new URLSearchParams({
        size: '15',
        page: '1',
        accountName: accountName,
        domainId: domainId
      });

      const res = await fetch(`${MAILY_API_URL}?${queryParams}`, {
        method: 'GET',
        cache: 'no-store',
        headers: {
          "Authorization": `Bearer ${MAILY_TOKEN}`,
          "Content-Type": "application/json"
        }
      });

      if (!res.ok) {
        return NextResponse.json({ error: 'ไม่สามารถเชื่อมต่อระบบ Maily Space ได้ชั่วคราว' }, { status: 500 });
      }

      const data = await res.json();
      const mails = data?.data?.mails || [];

      if (mails.length === 0) {
        return NextResponse.json({ error: `ไม่พบกล่องข้อความใดๆ สำหรับอีเมล ${email} ในขณะนี้` }, { status: 400 });
      }

      for (const mail of mails) {
        if (matchesApp(mail.from, mail.subject, appId)) {
          const htmlBody = mail.html || '';
          const otpCode = extractOtpCode(htmlBody);
          matchingMails.push({
            subject: mail.subject || 'ไม่มีหัวข้อ',
            from: mail.from || '',
            otp: otpCode,
            html_body: htmlBody
          });
        }
      }
    } else {
      // ---------------------------------------------------------
      // Check Database for Private IMAP Settings (Hotmail / Gmail / Custom Domain)
      // ---------------------------------------------------------
      const imapSetting = await prisma.emailImapSetting.findUnique({
        where: { domain: lowerEmail }
      });

      if (imapSetting && imapSetting.isActive) {
        // App Lock check
        if (imapSetting.appId && imapSetting.appId !== appId) {
          return NextResponse.json({ error: `อีเมลนี้ถูกล็อกให้ใช้เฉพาะกับแอป ${imapSetting.appId} เท่านั้น` }, { status: 400 });
        }

        // Channel B: Private IMAP Fetching
        const config = {
          imap: {
            user: imapSetting.user,
            password: imapSetting.password,
            host: imapSetting.host,
            port: imapSetting.port,
            tls: imapSetting.tls,
            authTimeout: 10000,
            tlsOptions: { rejectUnauthorized: false }
          }
        };

        try {
          const connection = await imaps.connect(config);
          await connection.openBox('INBOX');

          // Search criteria (last 3 hours)
          const delay = 3 * 3600 * 1000;
          const sinceDate = new Date(Date.now() - delay);
          const searchCriteria = ['ALL', ['SINCE', sinceDate.toISOString()]];
          const fetchOptions = { bodies: ['HEADER', 'TEXT', ''], struct: true, markSeen: false };

          const messages = await connection.search(searchCriteria, fetchOptions);

          for (const item of messages) {
            const allPart = item.parts.find(part => part.which === '');
            if (!allPart) continue;

            const id = item.attributes.uid;
            const idHeader = "Imap-Id: "+id+"\r\n";
            const mailBuffer = Buffer.concat([Buffer.from(idHeader), Buffer.from(allPart.body)]);
            
            const parsed = await simpleParser(mailBuffer);
            const fromLine = parsed.from?.text || '';
            const subjectLine = parsed.subject || '';

            if (matchesApp(fromLine, subjectLine, appId)) {
              const htmlBody = parsed.html || parsed.textAsHtml || parsed.text || '';
              const otpCode = extractOtpCode(htmlBody);

              matchingMails.push({
                subject: subjectLine,
                from: fromLine,
                otp: otpCode,
                html_body: htmlBody,
                date: parsed.date || item.attributes.date
              });
            }
          }
          connection.end();

          // Sort descending by date
          matchingMails.sort((a, b) => new Date(b.date) - new Date(a.date));

        } catch (imapErr) {
          console.error('[IMAP FETCH ERROR]:', imapErr);
          return NextResponse.json({ error: `ดึงอีเมลไม่สำเร็จ (กรุณาเช็คว่ารหัสผ่าน/App Password เซิร์ฟเวอร์ พอร์ต หรือการตั้งค่าความปลอดภัยถูกต้องหรือไม่)` }, { status: 500 });
        }

      } else {
        // ---------------------------------------------------------
        // Channel C: Fallback to Cloud Run API
        // ---------------------------------------------------------
        const appCode = getAppCode(appId);
        const queryParams = new URLSearchParams({
          senderEmail: originalEmail, // Send original case
          appCode: appCode
        });

        const res = await fetch(`${CLOUD_RUN_URL}?${queryParams}`, {
          method: 'GET',
          cache: 'no-store'
        });

        if (!res.ok) {
          return NextResponse.json({ error: 'ระบบคลาวด์เชื่อมต่อขัดข้องชั่วคราว กรุณาตรวจสอบอีเมลอีกครั้ง' }, { status: 500 });
        }

        const data = await res.json();
        const emails = data.emails || [];

        if (emails.length === 0) {
          return NextResponse.json({ 
            error: `ไม่พบอีเมลยืนยันตัวตนล่าสุดของ ${appId} ส่งมายัง ${originalEmail} (กรุณากดส่งรหัส OTP หรือตรวจสอบว่าได้ลงทะเบียนเมลนี้แล้ว)`
          }, { status: 400 });
        }

        for (const mail of emails) {
          const htmlBody = mail.html || '';
          const otpCode = extractOtpCode(htmlBody);
          matchingMails.push({
            subject: mail.subject || 'ไม่มีหัวข้อ',
            from: mail.sender || `${appId} Security`,
            otp: otpCode,
            html_body: htmlBody
          });
        }
      }
    }

    if (matchingMails.length === 0) {
      return NextResponse.json({ error: `ไม่พบอีเมลยืนยันตัวตนล่าสุดสำหรับ ${appId}` }, { status: 400 });
    }

    // Get the latest one
    const latestMail = matchingMails[0];
    
    return NextResponse.json({
      success: true,
      code: latestMail.otp || null,
      html_body: latestMail.html_body || ''
    });

  } catch (error) {
    console.error('[OTP FETCH API ERROR]:', error);
    return NextResponse.json({ error: 'เกิดข้อผิดพลาดภายในระบบ' }, { status: 500 });
  }
}
