import { Prompt, Inter } from "next/font/google";
import "./globals.css";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { prisma } from "@/db";

const prompt = Prompt({
  variable: "--font-prompt",
  subsets: ["thai", "latin"],
  weight: ["300", "400", "500", "600", "700"],
});

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
});

export async function generateMetadata() {
  const setting = await prisma.siteSetting.findUnique({ where: { id: 'default' } });
  const storeName = setting?.storeName || "mymuayy";
  
  return {
    title: `${storeName} • STORE - เติมเงินและสินค้าดิจิทัลออโต้`,
    description: "จำหน่ายแอปพรีเมียม สตรีมมิ่ง เติมเกม เติมเงินมือถือ บริการอัตโนมัติตลอด 24 ชั่วโมง สะดวก รวดเร็ว ปลอดภัย โทนขาวคลีนหรูหรา",
  };
}

export default async function RootLayout({ children }) {
  const setting = await prisma.siteSetting.findUnique({ where: { id: 'default' } });
  const siteSetting = setting || { storeName: 'mymuayy', logoUrl: '' };

  return (
    <html
      lang="th"
      className={`${prompt.variable} ${inter.variable} h-full antialiased`}
    >
      <body className="min-h-full flex flex-col bg-[#f0f6ff] text-[#0f1e3d]">
        <Header siteSetting={siteSetting} />
        <main className="flex-1 flex flex-col">
          {children}
        </main>
        <Footer siteSetting={siteSetting} />
      </body>
    </html>
  );
}
