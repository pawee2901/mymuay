'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  ArrowLeft, 
  Search, 
  RefreshCw, 
  Mail, 
  KeyRound, 
  CheckCircle, 
  AlertCircle,
  PlaySquare,
  Sparkles,
  Bot
} from 'lucide-react';

export default function OTPPage() {
  const router = useRouter();
  const [apps, setApps] = useState([]);
  const [selectedApp, setSelectedApp] = useState(null);
  const [emailInput, setEmailInput] = useState('');
  
  const [isFetching, setIsFetching] = useState(false);
  const [latestOtp, setLatestOtp] = useState(null);
  const [errorMsg, setErrorMsg] = useState('');
  
  // Fake initial apps until API is built
  const defaultApps = [
    { id: 'netflix', name: 'Netflix', icon: PlaySquare, color: 'text-red-500', bg: 'bg-red-50' },
    { id: 'disney', name: 'Disney+', icon: Sparkles, color: 'text-blue-500', bg: 'bg-blue-50' },
    { id: 'chatgpt', name: 'ChatGPT', icon: Bot, color: 'text-emerald-500', bg: 'bg-emerald-50' },
    { id: 'prime', name: 'Prime Video', icon: PlaySquare, color: 'text-cyan-500', bg: 'bg-cyan-50' },
  ];

  useEffect(() => {
    // ไม่มีการใช้ฐานข้อมูล ดึงข้อมูลจาก App พื้นฐานที่กำหนดไว้ด้านบนได้เลย
    setApps(defaultApps);
  }, []);

  const handleFetchOTP = async (e) => {
    e?.preventDefault();
    if (!selectedApp) {
      setErrorMsg('กรุณาเลือกแอปที่ต้องการรับรหัส');
      return;
    }
    if (!emailInput || !emailInput.includes('@')) {
      setErrorMsg('กรุณากรอกอีเมลให้ถูกต้อง');
      return;
    }

    setIsFetching(true);
    setErrorMsg('');
    setLatestOtp(null);

    try {
      const res = await fetch('/api/otp/fetch', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          appId: selectedApp.id || selectedApp.name,
          email: emailInput.trim() // <-- เอา toLowerCase() ออก เพื่อส่งตัวพิมพ์ใหญ่/เล็กให้ถูกต้องตามที่ลูกค้าพิมพ์
        })
      });
      
      const data = await res.json();
      
      if (res.ok && data.success) {
        setLatestOtp({
          code: data.code,
          html_body: data.html_body
        });
      } else {
        setErrorMsg(data.error || 'ไม่พบรหัส OTP หรือเกิดข้อผิดพลาด');
      }
    } catch (err) {
      console.error(err);
      setErrorMsg('เครือข่ายขัดข้อง กรุณาลองใหม่อีกครั้ง');
    } finally {
      setIsFetching(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50 font-sans relative overflow-hidden flex flex-col">
      
      {/* Decorative Background Blobs */}
      <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] rounded-full bg-indigo-300/20 blur-3xl pointer-events-none" />
      <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] rounded-full bg-pink-300/20 blur-3xl pointer-events-none" />

      <div className="max-w-2xl mx-auto px-4 py-8 flex-1 w-full relative z-10 flex flex-col items-center">
        
        {/* Header Back Button */}
        <div className="w-full mb-8 flex justify-start">
          <Link href="/" className="flex items-center gap-1.5 text-xs text-slate-500 hover:text-slate-800 transition-colors font-bold bg-white/50 backdrop-blur px-3 py-1.5 rounded-full border border-slate-200 shadow-sm">
            <ArrowLeft className="w-4 h-4" />
            กลับหน้าหลัก
          </Link>
        </div>

        {/* Title Area */}
        <div className="text-center mb-10 space-y-2">
          <motion.h1 
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-2xl md:text-3xl font-black bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent"
          >
            ยินดีต้อนรับสู่ mymuayy OTP
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.1 }}
            className="text-slate-500 text-sm font-medium"
          >
            ระบบดึงรหัสยืนยันอัตโนมัติ สะดวก รวดเร็ว ตลอด 24 ชม.
          </motion.p>
        </div>

        {/* Main Content Card */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white/80 backdrop-blur-xl border border-white/60 shadow-xl rounded-[2.5rem] p-6 md:p-10 w-full"
        >
          
          {/* STEP 1: Select App */}
          <div className="space-y-4 mb-10">
            <h2 className="text-center text-sm font-bold text-slate-700 flex flex-col items-center gap-1">
              <span>เลือกแอปที่ต้องการรับรหัสยืนยัน</span>
              <div className="w-0 h-0 border-l-[6px] border-l-transparent border-r-[6px] border-r-transparent border-t-[8px] border-t-slate-300 mt-1" />
            </h2>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {apps.map((app) => {
                const Icon = app.icon || Mail;
                const isSelected = selectedApp?.id === app.id;
                return (
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    key={app.id}
                    onClick={() => {
                      setSelectedApp(app);
                      setLatestOtp(null);
                      setErrorMsg('');
                    }}
                    className={`flex flex-col items-center justify-center p-4 rounded-3xl border-2 transition-all duration-300 ${
                      isSelected 
                        ? 'border-indigo-500 bg-indigo-50/50 shadow-md' 
                        : 'border-slate-100 bg-white hover:border-indigo-200 hover:shadow-sm'
                    }`}
                  >
                    <div className={`w-14 h-14 rounded-2xl flex items-center justify-center mb-3 ${app.bg || 'bg-slate-50'} ${app.color || 'text-slate-600'}`}>
                      {app.logoUrl ? (
                        <img src={app.logoUrl} alt={app.name} className="w-8 h-8 object-contain" />
                      ) : (
                        <Icon className="w-7 h-7" />
                      )}
                    </div>
                    <span className={`text-xs font-bold ${isSelected ? 'text-indigo-700' : 'text-slate-600'}`}>
                      {app.name}
                    </span>
                  </motion.button>
                )
              })}
            </div>
          </div>

          {/* STEP 2: Input Email & Search */}
          <AnimatePresence>
            {selectedApp && (
              <motion.div 
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="overflow-hidden"
              >
                <div className="border-t border-slate-100 pt-8 pb-4">
                  <h2 className="text-center text-sm font-bold text-slate-700 mb-4 flex items-center justify-center gap-2">
                    <Mail className="w-4 h-4 text-indigo-500" />
                    กล่องข้อความสำหรับ {selectedApp.name}
                  </h2>

                  <form onSubmit={handleFetchOTP} className="flex flex-col sm:flex-row gap-3">
                    <div className="relative flex-1">
                      <div className="absolute inset-y-0 left-4 flex items-center pointer-events-none">
                        <Search className="w-4 h-4 text-slate-400" />
                      </div>
                      <input 
                        type="email" 
                        required
                        placeholder="กรอกอีเมลของคุณ (เช่น user@lico.moe)"
                        value={emailInput}
                        onChange={(e) => setEmailInput(e.target.value)}
                        className="w-full pl-11 pr-4 py-3.5 bg-slate-50 border border-slate-200 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 rounded-2xl text-sm font-medium text-slate-800 outline-none transition-all"
                      />
                    </div>
                    <button 
                      type="submit"
                      disabled={isFetching}
                      className="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-3.5 rounded-2xl font-bold text-sm shadow-md transition-all flex items-center justify-center gap-2 disabled:opacity-70 disabled:cursor-not-allowed shrink-0"
                    >
                      {isFetching ? <RefreshCw className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4" />}
                      <span>{isFetching ? 'กำลังค้นหา...' : 'ค้นหารหัส'}</span>
                    </button>
                  </form>

                  {/* Errors */}
                  {errorMsg && (
                    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="mt-4 bg-rose-50 border border-rose-100 text-rose-600 text-xs font-bold p-3 rounded-xl flex items-start gap-2">
                      <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                      {errorMsg}
                    </motion.div>
                  )}
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* STEP 3: Results Display (Full HTML Style) */}
          <AnimatePresence>
            {latestOtp && (
              <motion.div 
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="mt-8 bg-white border border-slate-200 shadow-xl rounded-[2rem] overflow-hidden"
              >
                <div className="bg-slate-50 border-b border-slate-200 px-6 py-4 flex items-center justify-between">
                  <h3 className="text-sm font-bold text-slate-700">กล่องข้อความล่าสุดของ {emailInput}</h3>
                  <button 
                    onClick={() => setLatestOtp(null)} 
                    className="text-slate-400 hover:text-slate-600 font-medium text-sm transition-colors"
                  >
                    ปิด
                  </button>
                </div>
                
                <div className="p-0 bg-white w-full">
                  {latestOtp.html_body ? (
                    <div 
                      className="w-full max-w-full overflow-x-auto p-4 md:p-8 [&_table]:!max-w-full [&_table]:!w-full [&_img]:!max-w-full [&_img]:!h-auto"
                      dangerouslySetInnerHTML={{ __html: latestOtp.html_body }}
                    />
                  ) : (
                    <div className="p-8 text-center">
                      <p className="text-sm text-slate-600 font-medium mb-4">ไม่พบเนื้อหาอีเมล มีเพียงรหัส:</p>
                      <span className="text-5xl md:text-6xl font-black text-indigo-600 tracking-[0.25em] font-mono select-all">
                        {latestOtp.code}
                      </span>
                    </div>
                  )}
                </div>
              </motion.div>
            )}
          </AnimatePresence>

        </motion.div>

        <div className="mt-8 text-center">
          <p className="text-xs text-slate-400 font-medium">
            มีปัญหาการรับรหัส? <a href="#" className="text-indigo-500 hover:underline">ติดต่อแอดมิน</a>
          </p>
        </div>

      </div>
    </div>
  );
}
